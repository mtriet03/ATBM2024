﻿namespace PhanHe2
{
    partial class FormGrant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Grantfor = new System.Windows.Forms.Label();
            this.radioButtonRU = new System.Windows.Forms.RadioButton();
            this.labelNameG = new System.Windows.Forms.Label();
            this.textNameG = new System.Windows.Forms.TextBox();
            this.radioButtonUser = new System.Windows.Forms.RadioButton();
            this.checkBoxOpion = new System.Windows.Forms.CheckBox();
            this.panelOption = new System.Windows.Forms.Panel();
            this.checkBoxCustom = new System.Windows.Forms.CheckBox();
            this.checkBoxU = new System.Windows.Forms.CheckBox();
            this.checkBoxS = new System.Windows.Forms.CheckBox();
            this.checkBoxD = new System.Windows.Forms.CheckBox();
            this.checkBoxI = new System.Windows.Forms.CheckBox();
            this.labelOption = new System.Windows.Forms.Label();
            this.labelTable = new System.Windows.Forms.Label();
            this.textBoxTable = new System.Windows.Forms.TextBox();
            this.buttonGrant = new System.Windows.Forms.Button();
            this.textBoxForU = new System.Windows.Forms.TextBox();
            this.labelForU = new System.Windows.Forms.Label();
            this.panelNotRU = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonRU = new System.Windows.Forms.Button();
            this.textBoxRU = new System.Windows.Forms.TextBox();
            this.labelRU = new System.Windows.Forms.Label();
            this.panelOption.SuspendLayout();
            this.panelNotRU.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Grantfor
            // 
            this.Grantfor.AutoSize = true;
            this.Grantfor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Grantfor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.Grantfor.Location = new System.Drawing.Point(49, 7);
            this.Grantfor.Name = "Grantfor";
            this.Grantfor.Size = new System.Drawing.Size(52, 25);
            this.Grantfor.TabIndex = 0;
            this.Grantfor.Text = "Cấp";
            // 
            // radioButtonRU
            // 
            this.radioButtonRU.AutoSize = true;
            this.radioButtonRU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonRU.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.radioButtonRU.Location = new System.Drawing.Point(383, 7);
            this.radioButtonRU.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButtonRU.Name = "radioButtonRU";
            this.radioButtonRU.Size = new System.Drawing.Size(194, 24);
            this.radioButtonRU.TabIndex = 3;
            this.radioButtonRU.Text = "Role cho User/Role";
            this.radioButtonRU.UseVisualStyleBackColor = true;
            this.radioButtonRU.CheckedChanged += new System.EventHandler(this.radioButtonRU_CheckedChanged);
            // 
            // labelNameG
            // 
            this.labelNameG.AutoSize = true;
            this.labelNameG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNameG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.labelNameG.Location = new System.Drawing.Point(26, 45);
            this.labelNameG.Name = "labelNameG";
            this.labelNameG.Size = new System.Drawing.Size(130, 20);
            this.labelNameG.TabIndex = 4;
            this.labelNameG.Text = "Tên User/Role";
            // 
            // textNameG
            // 
            this.textNameG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNameG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.textNameG.Location = new System.Drawing.Point(29, 75);
            this.textNameG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textNameG.Name = "textNameG";
            this.textNameG.Size = new System.Drawing.Size(298, 26);
            this.textNameG.TabIndex = 5;
            // 
            // radioButtonUser
            // 
            this.radioButtonUser.AutoSize = true;
            this.radioButtonUser.Checked = true;
            this.radioButtonUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.radioButtonUser.Location = new System.Drawing.Point(121, 9);
            this.radioButtonUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButtonUser.Name = "radioButtonUser";
            this.radioButtonUser.Size = new System.Drawing.Size(209, 24);
            this.radioButtonUser.TabIndex = 6;
            this.radioButtonUser.TabStop = true;
            this.radioButtonUser.Text = "Quyền cho User/Role";
            this.radioButtonUser.UseVisualStyleBackColor = true;
            this.radioButtonUser.CheckedChanged += new System.EventHandler(this.radioButtonUser_CheckedChanged);
            // 
            // checkBoxOpion
            // 
            this.checkBoxOpion.AutoSize = true;
            this.checkBoxOpion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxOpion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.checkBoxOpion.Location = new System.Drawing.Point(11, 15);
            this.checkBoxOpion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxOpion.Name = "checkBoxOpion";
            this.checkBoxOpion.Size = new System.Drawing.Size(171, 24);
            this.checkBoxOpion.TabIndex = 7;
            this.checkBoxOpion.Text = "with grant option";
            this.checkBoxOpion.UseVisualStyleBackColor = true;
            // 
            // panelOption
            // 
            this.panelOption.Controls.Add(this.checkBoxCustom);
            this.panelOption.Controls.Add(this.checkBoxU);
            this.panelOption.Controls.Add(this.checkBoxS);
            this.panelOption.Controls.Add(this.checkBoxD);
            this.panelOption.Controls.Add(this.checkBoxI);
            this.panelOption.Controls.Add(this.labelOption);
            this.panelOption.Location = new System.Drawing.Point(10, 53);
            this.panelOption.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelOption.Name = "panelOption";
            this.panelOption.Size = new System.Drawing.Size(749, 57);
            this.panelOption.TabIndex = 8;
            // 
            // checkBoxCustom
            // 
            this.checkBoxCustom.AutoSize = true;
            this.checkBoxCustom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxCustom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.checkBoxCustom.Location = new System.Drawing.Point(631, 19);
            this.checkBoxCustom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxCustom.Name = "checkBoxCustom";
            this.checkBoxCustom.Size = new System.Drawing.Size(108, 29);
            this.checkBoxCustom.TabIndex = 4;
            this.checkBoxCustom.Text = "Custom";
            this.checkBoxCustom.UseVisualStyleBackColor = true;
            this.checkBoxCustom.CheckedChanged += new System.EventHandler(this.checkCustom_CheckedChanged);
            // 
            // checkBoxU
            // 
            this.checkBoxU.AutoSize = true;
            this.checkBoxU.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxU.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.checkBoxU.Location = new System.Drawing.Point(512, 18);
            this.checkBoxU.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxU.Name = "checkBoxU";
            this.checkBoxU.Size = new System.Drawing.Size(103, 29);
            this.checkBoxU.TabIndex = 4;
            this.checkBoxU.Text = "Update";
            this.checkBoxU.UseVisualStyleBackColor = true;
            this.checkBoxU.CheckedChanged += new System.EventHandler(this.checkBoxU_CheckedChanged);
            // 
            // checkBoxS
            // 
            this.checkBoxS.AutoSize = true;
            this.checkBoxS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.checkBoxS.Location = new System.Drawing.Point(382, 18);
            this.checkBoxS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxS.Name = "checkBoxS";
            this.checkBoxS.Size = new System.Drawing.Size(95, 29);
            this.checkBoxS.TabIndex = 3;
            this.checkBoxS.Text = "Select";
            this.checkBoxS.UseVisualStyleBackColor = true;
            // 
            // checkBoxD
            // 
            this.checkBoxD.AutoSize = true;
            this.checkBoxD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.checkBoxD.Location = new System.Drawing.Point(258, 18);
            this.checkBoxD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxD.Name = "checkBoxD";
            this.checkBoxD.Size = new System.Drawing.Size(96, 29);
            this.checkBoxD.TabIndex = 2;
            this.checkBoxD.Text = "Delete";
            this.checkBoxD.UseVisualStyleBackColor = true;
            // 
            // checkBoxI
            // 
            this.checkBoxI.AutoSize = true;
            this.checkBoxI.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.checkBoxI.Location = new System.Drawing.Point(144, 19);
            this.checkBoxI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxI.Name = "checkBoxI";
            this.checkBoxI.Size = new System.Drawing.Size(88, 29);
            this.checkBoxI.TabIndex = 1;
            this.checkBoxI.Text = "Insert";
            this.checkBoxI.UseVisualStyleBackColor = true;
            // 
            // labelOption
            // 
            this.labelOption.AutoSize = true;
            this.labelOption.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.labelOption.Location = new System.Drawing.Point(-4, 19);
            this.labelOption.Name = "labelOption";
            this.labelOption.Size = new System.Drawing.Size(142, 25);
            this.labelOption.TabIndex = 0;
            this.labelOption.Text = "Chọn quyền: ";
            // 
            // labelTable
            // 
            this.labelTable.AutoSize = true;
            this.labelTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTable.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.labelTable.Location = new System.Drawing.Point(6, 136);
            this.labelTable.Name = "labelTable";
            this.labelTable.Size = new System.Drawing.Size(96, 25);
            this.labelTable.TabIndex = 9;
            this.labelTable.Text = "Tên bảng";
            // 
            // textBoxTable
            // 
            this.textBoxTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTable.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.textBoxTable.Location = new System.Drawing.Point(113, 137);
            this.textBoxTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxTable.Name = "textBoxTable";
            this.textBoxTable.Size = new System.Drawing.Size(509, 26);
            this.textBoxTable.TabIndex = 10;
            // 
            // buttonGrant
            // 
            this.buttonGrant.AutoSize = true;
            this.buttonGrant.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.buttonGrant.FlatAppearance.BorderSize = 0;
            this.buttonGrant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGrant.Font = new System.Drawing.Font("Roboto", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGrant.ForeColor = System.Drawing.Color.White;
            this.buttonGrant.Location = new System.Drawing.Point(631, 137);
            this.buttonGrant.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonGrant.Name = "buttonGrant";
            this.buttonGrant.Size = new System.Drawing.Size(137, 30);
            this.buttonGrant.TabIndex = 11;
            this.buttonGrant.Text = "Thực hiện cấp";
            this.buttonGrant.UseVisualStyleBackColor = false;
            this.buttonGrant.Click += new System.EventHandler(this.buttonGrant_Click);
            // 
            // textBoxForU
            // 
            this.textBoxForU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxForU.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.textBoxForU.Location = new System.Drawing.Point(88, 133);
            this.textBoxForU.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxForU.Name = "textBoxForU";
            this.textBoxForU.Size = new System.Drawing.Size(288, 26);
            this.textBoxForU.TabIndex = 13;
            // 
            // labelForU
            // 
            this.labelForU.AutoSize = true;
            this.labelForU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelForU.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.labelForU.Location = new System.Drawing.Point(-4, 135);
            this.labelForU.Name = "labelForU";
            this.labelForU.Size = new System.Drawing.Size(72, 20);
            this.labelForU.TabIndex = 13;
            this.labelForU.Text = "Tên cột";
            // 
            // panelNotRU
            // 
            this.panelNotRU.Controls.Add(this.panel1);
            this.panelNotRU.Controls.Add(this.checkBoxOpion);
            this.panelNotRU.Controls.Add(this.buttonGrant);
            this.panelNotRU.Controls.Add(this.panelOption);
            this.panelNotRU.Controls.Add(this.labelTable);
            this.panelNotRU.Controls.Add(this.textBoxTable);
            this.panelNotRU.Location = new System.Drawing.Point(19, 111);
            this.panelNotRU.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelNotRU.Name = "panelNotRU";
            this.panelNotRU.Size = new System.Drawing.Size(775, 231);
            this.panelNotRU.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(10, 174);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(615, 42);
            this.panel1.TabIndex = 15;
            this.panel1.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.textBox1.Location = new System.Drawing.Point(103, 2);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(509, 27);
            this.textBox1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label1.Location = new System.Drawing.Point(5, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Tên cột";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttonRU);
            this.panel2.Controls.Add(this.textBoxRU);
            this.panel2.Controls.Add(this.labelRU);
            this.panel2.Location = new System.Drawing.Point(349, 35);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(445, 72);
            this.panel2.TabIndex = 14;
            this.panel2.Visible = false;
            // 
            // buttonRU
            // 
            this.buttonRU.AutoSize = true;
            this.buttonRU.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.buttonRU.FlatAppearance.BorderSize = 0;
            this.buttonRU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRU.Font = new System.Drawing.Font("Roboto", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRU.ForeColor = System.Drawing.Color.White;
            this.buttonRU.Location = new System.Drawing.Point(292, 36);
            this.buttonRU.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonRU.Name = "buttonRU";
            this.buttonRU.Size = new System.Drawing.Size(137, 30);
            this.buttonRU.TabIndex = 13;
            this.buttonRU.Text = "Thực hiện cấp";
            this.buttonRU.UseVisualStyleBackColor = false;
            this.buttonRU.Click += new System.EventHandler(this.buttonRU_Click);
            // 
            // textBoxRU
            // 
            this.textBoxRU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxRU.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.textBoxRU.Location = new System.Drawing.Point(16, 40);
            this.textBoxRU.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxRU.Name = "textBoxRU";
            this.textBoxRU.Size = new System.Drawing.Size(258, 26);
            this.textBoxRU.TabIndex = 15;
            // 
            // labelRU
            // 
            this.labelRU.AutoSize = true;
            this.labelRU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRU.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.labelRU.Location = new System.Drawing.Point(12, 10);
            this.labelRU.Name = "labelRU";
            this.labelRU.Size = new System.Drawing.Size(166, 20);
            this.labelRU.TabIndex = 15;
            this.labelRU.Text = "Tên Role được cấp";
            // 
            // FormGrant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(806, 338);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelNotRU);
            this.Controls.Add(this.radioButtonUser);
            this.Controls.Add(this.textNameG);
            this.Controls.Add(this.labelNameG);
            this.Controls.Add(this.radioButtonRU);
            this.Controls.Add(this.Grantfor);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormGrant";
            this.Text = "Grant";
            this.panelOption.ResumeLayout(false);
            this.panelOption.PerformLayout();
            this.panelNotRU.ResumeLayout(false);
            this.panelNotRU.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Grantfor;
        private System.Windows.Forms.RadioButton radioButtonRU;
        private System.Windows.Forms.Label labelNameG;
        private System.Windows.Forms.TextBox textNameG;
        private System.Windows.Forms.RadioButton radioButtonUser;
        private System.Windows.Forms.CheckBox checkBoxOpion;
        private System.Windows.Forms.Panel panelOption;
        private System.Windows.Forms.Label labelOption;
        private System.Windows.Forms.CheckBox checkBoxU;
        private System.Windows.Forms.CheckBox checkBoxS;
        private System.Windows.Forms.CheckBox checkBoxD;
        private System.Windows.Forms.CheckBox checkBoxI;
        private System.Windows.Forms.Label labelTable;
        private System.Windows.Forms.TextBox textBoxTable;
        private System.Windows.Forms.Button buttonGrant;
        private System.Windows.Forms.Label labelForU;
        private System.Windows.Forms.TextBox textBoxForU;
        private System.Windows.Forms.Panel panelNotRU;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonRU;
        private System.Windows.Forms.TextBox textBoxRU;

        private System.Windows.Forms.Label labelRU;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBoxCustom;
    }
}