﻿namespace PhanHe2
{
    partial class PH2_DK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.p_diem = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelDiemTh = new System.Windows.Forms.Label();
            this.tB_DCK = new System.Windows.Forms.TextBox();
            this.tB_DTQ = new System.Windows.Forms.TextBox();
            this.tB_DTK = new System.Windows.Forms.TextBox();
            this.tB_dTH = new System.Windows.Forms.TextBox();
            this.btn_u = new System.Windows.Forms.Button();
            this.tB_idDK = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_d = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.themdangky = new System.Windows.Forms.Panel();
            this.comboBoxCT = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbmagv = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbmasv = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbhk = new System.Windows.Forms.TextBox();
            this.tbnam = new System.Windows.Forms.TextBox();
            this.tbmhp = new System.Windows.Forms.TextBox();
            this.panelID = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.p_diem.SuspendLayout();
            this.themdangky.SuspendLayout();
            this.panelID.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // p_diem
            // 
            this.p_diem.Controls.Add(this.label3);
            this.p_diem.Controls.Add(this.label2);
            this.p_diem.Controls.Add(this.label1);
            this.p_diem.Controls.Add(this.labelDiemTh);
            this.p_diem.Controls.Add(this.tB_DCK);
            this.p_diem.Controls.Add(this.tB_DTQ);
            this.p_diem.Controls.Add(this.tB_DTK);
            this.p_diem.Controls.Add(this.tB_dTH);
            this.p_diem.Location = new System.Drawing.Point(460, 545);
            this.p_diem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.p_diem.Name = "p_diem";
            this.p_diem.Size = new System.Drawing.Size(269, 149);
            this.p_diem.TabIndex = 1;
            this.p_diem.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label3.Location = new System.Drawing.Point(151, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Điểm CK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label2.Location = new System.Drawing.Point(16, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Điểm QT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label1.Location = new System.Drawing.Point(151, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Điểm TK";
            // 
            // labelDiemTh
            // 
            this.labelDiemTh.AutoSize = true;
            this.labelDiemTh.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDiemTh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.labelDiemTh.Location = new System.Drawing.Point(16, 26);
            this.labelDiemTh.Name = "labelDiemTh";
            this.labelDiemTh.Size = new System.Drawing.Size(78, 20);
            this.labelDiemTh.TabIndex = 4;
            this.labelDiemTh.Text = "Điểm TH";
            // 
            // tB_DCK
            // 
            this.tB_DCK.Location = new System.Drawing.Point(155, 49);
            this.tB_DCK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tB_DCK.Name = "tB_DCK";
            this.tB_DCK.Size = new System.Drawing.Size(100, 26);
            this.tB_DCK.TabIndex = 3;
            // 
            // tB_DTQ
            // 
            this.tB_DTQ.Location = new System.Drawing.Point(12, 115);
            this.tB_DTQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tB_DTQ.Name = "tB_DTQ";
            this.tB_DTQ.Size = new System.Drawing.Size(100, 26);
            this.tB_DTQ.TabIndex = 2;
            // 
            // tB_DTK
            // 
            this.tB_DTK.Location = new System.Drawing.Point(155, 115);
            this.tB_DTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tB_DTK.Name = "tB_DTK";
            this.tB_DTK.Size = new System.Drawing.Size(100, 26);
            this.tB_DTK.TabIndex = 1;
            // 
            // tB_dTH
            // 
            this.tB_dTH.Location = new System.Drawing.Point(12, 51);
            this.tB_dTH.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tB_dTH.Name = "tB_dTH";
            this.tB_dTH.Size = new System.Drawing.Size(100, 26);
            this.tB_dTH.TabIndex = 0;
            // 
            // btn_u
            // 
            this.btn_u.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.btn_u.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_u.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_u.ForeColor = System.Drawing.Color.White;
            this.btn_u.Location = new System.Drawing.Point(800, 580);
            this.btn_u.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_u.Name = "btn_u";
            this.btn_u.Size = new System.Drawing.Size(159, 44);
            this.btn_u.TabIndex = 2;
            this.btn_u.Text = "Cập nhật";
            this.btn_u.UseVisualStyleBackColor = false;
            this.btn_u.Visible = false;
            this.btn_u.Click += new System.EventHandler(this.btn_u_Click);
            // 
            // tB_idDK
            // 
            this.tB_idDK.Location = new System.Drawing.Point(7, 49);
            this.tB_idDK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tB_idDK.Name = "tB_idDK";
            this.tB_idDK.Size = new System.Drawing.Size(98, 26);
            this.tB_idDK.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label4.Location = new System.Drawing.Point(3, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "ID_DangKy";
            // 
            // btn_d
            // 
            this.btn_d.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.btn_d.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_d.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_d.ForeColor = System.Drawing.Color.White;
            this.btn_d.Location = new System.Drawing.Point(800, 516);
            this.btn_d.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_d.Name = "btn_d";
            this.btn_d.Size = new System.Drawing.Size(159, 44);
            this.btn_d.TabIndex = 5;
            this.btn_d.Text = "Xoá đăng ký";
            this.btn_d.UseVisualStyleBackColor = false;
            this.btn_d.Visible = false;
            this.btn_d.Click += new System.EventHandler(this.btn_d_Click);
            // 
            // btn_I
            // 
            this.btn_I.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.btn_I.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_I.ForeColor = System.Drawing.Color.White;
            this.btn_I.Location = new System.Drawing.Point(800, 644);
            this.btn_I.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(159, 50);
            this.btn_I.TabIndex = 6;
            this.btn_I.Text = "Thêm đăng ký";
            this.btn_I.UseVisualStyleBackColor = false;
            this.btn_I.Visible = false;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // themdangky
            // 
            this.themdangky.Controls.Add(this.comboBoxCT);
            this.themdangky.Controls.Add(this.label10);
            this.themdangky.Controls.Add(this.tbmagv);
            this.themdangky.Controls.Add(this.label9);
            this.themdangky.Controls.Add(this.tbmasv);
            this.themdangky.Controls.Add(this.label5);
            this.themdangky.Controls.Add(this.label6);
            this.themdangky.Controls.Add(this.label7);
            this.themdangky.Controls.Add(this.label8);
            this.themdangky.Controls.Add(this.tbhk);
            this.themdangky.Controls.Add(this.tbnam);
            this.themdangky.Controls.Add(this.tbmhp);
            this.themdangky.Location = new System.Drawing.Point(14, 502);
            this.themdangky.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.themdangky.Name = "themdangky";
            this.themdangky.Size = new System.Drawing.Size(269, 191);
            this.themdangky.TabIndex = 8;
            this.themdangky.Visible = false;
            // 
            // comboBoxCT
            // 
            this.comboBoxCT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCT.FormattingEnabled = true;
            this.comboBoxCT.Items.AddRange(new object[] {
            "CLC",
            "CQ",
            "CTTT"});
            this.comboBoxCT.Location = new System.Drawing.Point(150, 158);
            this.comboBoxCT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBoxCT.Name = "comboBoxCT";
            this.comboBoxCT.Size = new System.Drawing.Size(103, 28);
            this.comboBoxCT.TabIndex = 12;
            this.comboBoxCT.SelectedIndexChanged += new System.EventHandler(this.comboBoxCT_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label10.Location = new System.Drawing.Point(159, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 20);
            this.label10.TabIndex = 11;
            this.label10.Text = "Mã GV";
            // 
            // tbmagv
            // 
            this.tbmagv.Location = new System.Drawing.Point(155, 34);
            this.tbmagv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbmagv.Name = "tbmagv";
            this.tbmagv.Size = new System.Drawing.Size(100, 26);
            this.tbmagv.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label9.Location = new System.Drawing.Point(14, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 20);
            this.label9.TabIndex = 9;
            this.label9.Text = "Mã SV";
            // 
            // tbmasv
            // 
            this.tbmasv.Location = new System.Drawing.Point(10, 34);
            this.tbmasv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbmasv.Name = "tbmasv";
            this.tbmasv.Size = new System.Drawing.Size(100, 26);
            this.tbmasv.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label5.Location = new System.Drawing.Point(148, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "HK";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label6.Location = new System.Drawing.Point(14, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Năm";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label7.Location = new System.Drawing.Point(148, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Mã CT";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.label8.Location = new System.Drawing.Point(14, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "Mã học phần";
            // 
            // tbhk
            // 
            this.tbhk.Location = new System.Drawing.Point(153, 94);
            this.tbhk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbhk.Name = "tbhk";
            this.tbhk.Size = new System.Drawing.Size(100, 26);
            this.tbhk.TabIndex = 3;
            // 
            // tbnam
            // 
            this.tbnam.Location = new System.Drawing.Point(10, 158);
            this.tbnam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbnam.Name = "tbnam";
            this.tbnam.Size = new System.Drawing.Size(100, 26);
            this.tbnam.TabIndex = 2;
            // 
            // tbmhp
            // 
            this.tbmhp.Location = new System.Drawing.Point(10, 94);
            this.tbmhp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbmhp.Name = "tbmhp";
            this.tbmhp.Size = new System.Drawing.Size(100, 26);
            this.tbmhp.TabIndex = 0;
            // 
            // panelID
            // 
            this.panelID.Controls.Add(this.label4);
            this.panelID.Controls.Add(this.tB_idDK);
            this.panelID.Location = new System.Drawing.Point(306, 545);
            this.panelID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelID.Name = "panelID";
            this.panelID.Size = new System.Drawing.Size(124, 88);
            this.panelID.TabIndex = 9;
            this.panelID.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.dataGridView1.Location = new System.Drawing.Point(14, 15);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(955, 460);
            this.dataGridView1.TabIndex = 11;
            // 
            // PH2_DK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1018, 742);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.themdangky);
            this.Controls.Add(this.btn_I);
            this.Controls.Add(this.btn_d);
            this.Controls.Add(this.btn_u);
            this.Controls.Add(this.p_diem);
            this.Controls.Add(this.panelID);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "PH2_DK";
            this.Text = "Đăng ký";
            this.Load += new System.EventHandler(this.PH2_DK_Load);
            this.p_diem.ResumeLayout(false);
            this.p_diem.PerformLayout();
            this.themdangky.ResumeLayout(false);
            this.themdangky.PerformLayout();
            this.panelID.ResumeLayout(false);
            this.panelID.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel p_diem;
        private System.Windows.Forms.Label labelDiemTh;
        private System.Windows.Forms.TextBox tB_DCK;
        private System.Windows.Forms.TextBox tB_DTQ;
        private System.Windows.Forms.TextBox tB_DTK;
        private System.Windows.Forms.TextBox tB_dTH;
        private System.Windows.Forms.Button btn_u;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tB_idDK;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_d;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Panel themdangky;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbhk;
        private System.Windows.Forms.TextBox tbnam;
        private System.Windows.Forms.TextBox tbmhp;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbmagv;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbmasv;
        private System.Windows.Forms.Panel panelID;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox comboBoxCT;
    }
}