﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhanHe2
{
    public static class ThemeColor
    {
        //Hex value for colors
        public static List<string> ColorList = new List<string>() { "#207a7d" };
    }
}
